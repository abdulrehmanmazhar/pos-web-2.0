import { createSelector } from "reselect";
import { selectCurrentInventories } from "../inventorySlice";

export const filteredInventories = createSelector([selectCurrentInventories], (inventories)=>{
    return inventories.map(item=>({
        id: item._id,
        name: item.name,
        category: item.category,
        stockStatus: item.inStock,
        salePrice: item.price,
        purchasePrice: item.history[item.history.length-1].purchasePrice,
        discount: item.discount,
        sold: item.productSale.reduce((acc, item)=>acc+item.sold,0),
        currentStock: item.stockQty


        // createdBy: item.createdByUser?.name || "N/A",
    }))
})