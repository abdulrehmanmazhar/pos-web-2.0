import { createSlice } from "@reduxjs/toolkit";

const inventorySlice = createSlice({
    name: 'inventories',
    initialState: {
        inventories: [],
    },
    reducers:{
        setInventories: (state, action) =>{
            state.inventories = action.payload;
        }
    }
});

export default inventorySlice.reducer;
export const {setInventories} = inventorySlice.actions;

export const selectCurrentInventories = (state) => state.inventories;
