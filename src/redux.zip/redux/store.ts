import {configureStore} from '@reduxjs/toolkit';
import authReducer from './slices/authSlice';
import { apiSlice } from './apis/apiSlice';
import customerReducer from "./slices/customersSlice";
import inventoryReducer from './slices/customersSlice';
const store = configureStore({
    reducer:{
        [apiSlice.reducerPath]: apiSlice.reducer,
        auth: authReducer,
        customers: customerReducer,
        inventories: inventoryReducer,
    },
    devTools: true,
    middleware: (getDefaultMiddleware)=>getDefaultMiddleware().concat(apiSlice.middleware)
})

export default store;